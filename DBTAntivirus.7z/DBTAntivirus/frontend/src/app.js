// app.js - Main JavaScript for DBT Antivirus Frontend

document.addEventListener('DOMContentLoaded', function() {
    // Elements
    const fileInput = document.getElementById('fileInput');
    const uploadZone = document.getElementById('uploadZone');
    const browseLink = document.getElementById('browseLink');
    const scanBtn = document.getElementById('scanBtn');
    const fileInfo = document.getElementById('fileInfo');
    const resultsPlaceholder = document.getElementById('resultsPlaceholder');
    const resultsContainer = document.getElementById('resultsContainer');
    const verdictCard = document.getElementById('verdictCard');
    
    // File state
    let selectedFile = null;
    
    // API Configuration
    const API_BASE_URL = 'http://localhost:5000/api';
    
    // Initialize
    checkAPIStatus();
    loadStats();
    
    // ========== EVENT LISTENERS ==========
    
    // File selection via click
    browseLink.addEventListener('click', () => fileInput.click());
    uploadZone.addEventListener('click', () => fileInput.click());
    
    // File selection via input
    fileInput.addEventListener('change', (e) => {
        if (e.target.files.length > 0) {
            handleFileSelect(e.target.files[0]);
        }
    });
    
    // Drag & Drop
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        uploadZone.addEventListener(eventName, preventDefaults, false);
    });
    
    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }
    
    ['dragenter', 'dragover'].forEach(eventName => {
        uploadZone.addEventListener(eventName, () => {
            uploadZone.classList.add('dragover');
        }, false);
    });
    
    ['dragleave', 'drop'].forEach(eventName => {
        uploadZone.addEventListener(eventName, () => {
            uploadZone.classList.remove('dragover');
        }, false);
    });
    
    uploadZone.addEventListener('drop', (e) => {
        const dt = e.dataTransfer;
        const file = dt.files[0];
        handleFileSelect(file);
    }, false);
    
    // Scan button
    scanBtn.addEventListener('click', startScan);
    
    // ========== FILE HANDLING ==========
    
    function handleFileSelect(file) {
        if (!file) return;
        
        selectedFile = file;
        
        // Update UI
        document.getElementById('fileName').textContent = file.name;
        document.getElementById('fileSize').textContent = formatFileSize(file.size);
        
        fileInfo.style.display = 'block';
        scanBtn.disabled = false;
        resultsPlaceholder.style.display = 'block';
        resultsContainer.style.display = 'none';
        verdictCard.style.display = 'none';
        
        // Calculate hash (simulated for now)
        calculateFileHash(file).then(hash => {
            document.getElementById('fileHash').textContent = 
                hash.substring(0, 16) + '...' + hash.substring(hash.length - 16);
        });
    }
    
    async function calculateFileHash(file) {
        // Simulated hash calculation
        return new Promise(resolve => {
            const reader = new FileReader();
            reader.onload = function(e) {
                // In a real app, you would use crypto.subtle.digest
                const buffer = e.target.result;
                const hash = Array.from(new Uint8Array(buffer))
                    .map(b => b.toString(16).padStart(2, '0'))
                    .join('');
                resolve(hash.substring(0, 64)); // Simulate SHA-256 length
            };
            reader.readAsArrayBuffer(file.slice(0, 1024)); // Read first 1KB only
        });
    }
    
    // ========== SCAN PROCESS ==========
    
    async function startScan() {
        if (!selectedFile) return;
        
        // Disable UI
        scanBtn.disabled = true;
        scanBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i><span>Scanning...</span>';
        
        // Show progress
        const progressContainer = document.getElementById('progressContainer');
        const progressFill = document.getElementById('progressFill');
        const progressPercent = document.getElementById('progressPercent');
        const progressText = document.getElementById('progressText');
        
        progressContainer.style.display = 'block';
        updateProgress(0, 'Preparing scan...');
        
        try {
            // 1. Prepare form data
            const formData = new FormData();
            formData.append('file', selectedFile);
            
            // 2. Send to API
            updateProgress(30, 'Sending to DBT Scanner...');
            
            const response = await fetch(`${API_BASE_URL}/scan`, {
                method: 'POST',
                body: formData
            });
            
            if (!response.ok) {
                throw new Error(`API error: ${response.status}`);
            }
            
            updateProgress(70, 'Analyzing with multiple engines...');
            
            const result = await response.json();
            
            updateProgress(90, 'Generating report...');
            
            // 3. Display results
            displayResults(result);
            updateProgress(100, 'Scan complete!');
            
            // 4. Update stats
            loadStats();
            
        } catch (error) {
            console.error('Scan error:', error);
            showError(`Scan failed: ${error.message}`);
            updateProgress(0, 'Scan failed');
        } finally {
            // Reset UI
            setTimeout(() => {
                scanBtn.disabled = false;
                scanBtn.innerHTML = '<i class="fas fa-search"></i><span>Scan Another File</span>';
                progressContainer.style.display = 'none';
                progressFill.style.width = '0%';
            }, 1500);
        }
        
        function updateProgress(percent, text) {
            progressFill.style.width = `${percent}%`;
            progressPercent.textContent = `${percent}%`;
            progressText.textContent = text;
        }
    }
    
    // ========== RESULTS DISPLAY ==========
    
    function displayResults(result) {
        resultsPlaceholder.style.display = 'none';
        resultsContainer.style.display = 'block';
        verdictCard.style.display = 'block';
        
        // Clear previous results
        resultsContainer.innerHTML = '';
        
        // Display engine results
        if (result.engines) {
            for (const [engineName, engineResult] of Object.entries(result.engines)) {
                const engineCard = createEngineCard(engineName, engineResult);
                resultsContainer.appendChild(engineCard);
            }
        }
        
        // Display verdict
        if (result.verdict) {
            document.getElementById('verdictText').textContent = result.verdict.text;
            document.getElementById('verdictBadge').textContent = 
                result.verdict.level.toUpperCase();
            
            // Update badge color
            const badge = document.getElementById('verdictBadge');
            badge.style.background = result.verdict.color;
            
            // Update verdict card border
            verdictCard.style.borderColor = result.verdict.color;
        }
    }
    
    function createEngineCard(engineName, result) {
        const card = document.createElement('div');
        card.className = 'engine-result';
        
        // Status color
        let statusClass = 'status-warning';
        let statusText = 'PENDING';
        
        if (result.status === 'completed' || result.status === 'simulated') {
            statusClass = 'status-success';
            statusText = result.detections > 0 ? 'THREATS' : 'CLEAN';
        }
        
        // Engine icon
        const icons = {
            virustotal: 'fa-cloud',
            clamav: 'fa-server',
            anyrun: 'fa-play-circle'
        };
        
        card.innerHTML = `
            <div class="engine-header">
                <div class="engine-name">
                    <i class="fas ${icons[engineName] || 'fa-cogs'}"></i>
                    <span>${engineName.toUpperCase()}</span>
                </div>
                <div class="engine-status ${statusClass}">${statusText}</div>
            </div>
            <div class="engine-details">
                ${result.message || ''}
                ${result.detections !== undefined ? 
                    `<p>Detections: <strong>${result.detections}/${result.total || 72}</strong></p>` : ''}
                ${result.result ? `<p>Result: <code>${result.result}</code></p>` : ''}
                ${result.permalink ? 
                    `<a href="${result.permalink}" target="_blank" style="color: #6366f1;">
                        <i class="fas fa-external-link-alt"></i> View full report
                    </a>` : ''}
            </div>
        `;
        
        return card;
    }
    
    // ========== API STATUS & STATS ==========
    
    async function checkAPIStatus() {
        const statusBadge = document.getElementById('apiStatus');
        
        try {
            const response = await fetch(`${API_BASE_URL}/status`);
            if (response.ok) {
                statusBadge.innerHTML = '<i class="fas fa-circle"></i><span>API ONLINE</span>';
                statusBadge.style.background = 'rgba(16, 185, 129, 0.1)';
                statusBadge.style.borderColor = '#10b981';
            } else {
                throw new Error('API offline');
            }
        } catch (error) {
            statusBadge.innerHTML = '<i class="fas fa-circle"></i><span>API OFFLINE</span>';
            statusBadge.style.background = 'rgba(239, 68, 68, 0.1)';
            statusBadge.style.borderColor = '#ef4444';
        }
    }
    
    async function loadStats() {
        try {
            const response = await fetch(`${API_BASE_URL}/stats`);
            if (response.ok) {
                const data = await response.json();
                if (data.success) {
                    document.getElementById('totalScans').textContent = data.stats.total;
                    document.getElementById('cleanScans').textContent = data.stats.clean;
                    document.getElementById('threatsFound').textContent = 
                        data.stats.suspicious + data.stats.dangerous;
                }
            }
        } catch (error) {
            console.error('Failed to load stats:', error);
        }
    }
    
    // ========== UTILITIES ==========
    
    function formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }
    
    function showError(message) {
        alert(`Error: ${message}`);
    }
});