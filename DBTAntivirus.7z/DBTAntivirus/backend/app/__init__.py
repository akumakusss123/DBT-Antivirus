from flask import Flask
from flask_cors import CORS
import os

def create_app():
    app = Flask(__name__)
    
    # Разрешаем CORS для всех
    CORS(app)
    
    # Настройки
    app.config['MAX_CONTENT_LENGTH'] = 32 * 1024 * 1024  # 32MB
    app.config['UPLOAD_FOLDER'] = 'uploads'
    
    # Создаем папку для загрузок
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    
    # Регистрируем API роуты
    from .api.routes import api as api_blueprint
    app.register_blueprint(api_blueprint, url_prefix='/api')
    
    return app