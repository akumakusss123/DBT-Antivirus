import requests
import hashlib
import os
import subprocess
import json
from datetime import datetime
from pathlib import Path

class Scanner:
    def __init__(self, api_key=None):
        self.vt_api_key = api_key or os.getenv('VIRUSTOTAL_API_KEY')
        self.clamav_path = self._find_clamav()
    
    def _find_clamav(self):
        """Ищем ClamAV в типичных местах"""
        possible_paths = [
            r"C:\Program Files\ClamAV\clamscan.exe",
            r"C:\clamav\clamscan.exe",
            r"C:\Program Files (x86)\ClamAV\clamscan.exe",
            "/usr/bin/clamscan",
            "/usr/local/bin/clamscan"
        ]
        
        for path in possible_paths:
            if os.path.exists(path):
                print(f"✅ ClamAV найден: {path}")
                return path
        
        print("⚠️ ClamAV не найден. Установите ClamAV для локального сканирования.")
        return None
    
    def scan_file(self, file_path):
        """Основная функция сканирования"""
        print(f"🔍 Начинаем сканирование: {file_path}")
        
        # 1. Вычисляем хеш
        file_hash = self._calculate_hash(file_path)
        print(f"📊 SHA-256: {file_hash}")
        
        # 2. Проверяем в VirusTotal (параллельно можно запустить ClamAV)
        vt_result = self._check_virustotal(file_hash, file_path)
        
        # 3. Проверяем в ClamAV
        clamav_result = self._check_clamav(file_path)
        
        # 4. Формируем результат
        result = {
            'filename': os.path.basename(file_path),
            'hash': file_hash,
            'timestamp': datetime.now().isoformat(),
            'virustotal': vt_result,
            'clamav': clamav_result
        }
        
        # 5. Определяем общий статус
        if vt_result.get('detected', False) or clamav_result.get('detected', False):
            result['status'] = 'THREAT_DETECTED'
        else:
            result['status'] = 'CLEAN'
            
        return result
    
    def _calculate_hash(self, file_path):
        """Вычисляет SHA-256 хеш файла"""
        sha256_hash = hashlib.sha256()
        with open(file_path, "rb") as f:
            for byte_block in iter(lambda: f.read(4096), b""):
                sha256_hash.update(byte_block)
        return sha256_hash.hexdigest()
    
    def _check_virustotal(self, file_hash, file_path=None):
        """Проверяет файл в VirusTotal"""
        if not self.vt_api_key:
            return {'error': 'No API key', 'detected': False}
        
        try:
            # Сначала проверяем по хешу
            url = f'https://www.virustotal.com/api/v3/files/{file_hash}'
            headers = {'x-apikey': self.vt_api_key}
            
            response = requests.get(url, headers=headers, timeout=30)
            
            # Если файл уже есть в базе
            if response.status_code == 200:
                data = response.json()
                stats = data['data']['attributes']['last_analysis_stats']
                
                return {
                    'detected': stats['malicious'] > 0,
                    'malicious': stats['malicious'],
                    'suspicious': stats['suspicious'],
                    'undetected': stats['undetected'],
                    'harmless': stats['harmless'],
                    'timeout': stats['timeout'],
                    'source': 'hash_lookup'
                }
            
            # Если файла нет, загружаем его
            elif response.status_code == 404 and file_path:
                return self._upload_to_virustotal(file_path)
            
            else:
                return {'error': f'VT API error: {response.status_code}', 'detected': False}
                
        except Exception as e:
            return {'error': str(e), 'detected': False}
    
    def _upload_to_virustotal(self, file_path):
        """Загружает файл в VirusTotal для анализа"""
        try:
            # Получаем URL для загрузки
            upload_url = 'https://www.virustotal.com/api/v3/files/upload_url'
            headers = {'x-apikey': self.vt_api_key}
            
            response = requests.get(upload_url, headers=headers, timeout=30)
            if response.status_code != 200:
                return {'error': 'Cannot get upload URL', 'detected': False}
            
            upload_url = response.json()['data']
            
            # Загружаем файл
            with open(file_path, 'rb') as f:
                files = {'file': (os.path.basename(file_path), f)}
                response = requests.post(upload_url, files=files, headers=headers, timeout=60)
            
            if response.status_code == 200:
                return {
                    'detected': False,  # Результат будет позже
                    'message': 'File uploaded for analysis',
                    'analysis_id': response.json()['data']['id'],
                    'source': 'uploaded'
                }
            else:
                return {'error': f'Upload failed: {response.status_code}', 'detected': False}
                
        except Exception as e:
            return {'error': str(e), 'detected': False}
    
    def _check_clamav(self, file_path):
        """Проверяет файл через ClamAV"""
        if not self.clamav_path:
            return {'detected': False, 'result': 'ClamAV not installed'}
        
        try:
            # Запускаем clamscan
            cmd = [self.clamav_path, '--no-summary', '--stdout', file_path]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            
            if result.returncode == 0:
                # Файл чистый
                return {'detected': False, 'result': 'Clean'}
            elif result.returncode == 1:
                # Найден вирус
                output = result.stdout.strip()
                threat_name = output.split(': ')[-1] if ': ' in output else 'Unknown threat'
                return {'detected': True, 'result': threat_name}
            else:
                return {'detected': False, 'result': f'Error: {result.stderr[:100]}'}
                
        except subprocess.TimeoutExpired:
            return {'detected': False, 'result': 'Timeout'}
        except Exception as e:
            return {'detected': False, 'result': str(e)}