from flask import Blueprint, request, jsonify
import os
import tempfile
from app.scanner import Scanner

api = Blueprint('api', __name__)

@api.route('/scan', methods=['POST'])
def scan_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
    
    # Сохраняем временный файл
    temp_dir = tempfile.gettempdir()
    temp_path = os.path.join(temp_dir, file.filename)
    file.save(temp_path)
    
    try:
        # Сканируем файл
        scanner = Scanner()
        result = scanner.scan_file(temp_path)
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        # Удаляем временный файл
        if os.path.exists(temp_path):
            os.remove(temp_path)

@api.route('/status', methods=['GET'])
def api_status():
    return jsonify({
        'service': 'DBT Antivirus API',
        'status': 'online',
        'version': '1.0.0'
    })

@api.route('/history', methods=['GET'])
def history():
    return jsonify([])

@api.route('/stats', methods=['GET'])
def stats():
    return jsonify({
        'total_scans': 0,
        'clean_files': 0,
        'threats_found': 0
    })