from flask import Blueprint, jsonify
from datetime import datetime
import json
import os

bp = Blueprint('history', __name__, url_prefix='/api')

HISTORY_FILE = 'scans_history.json'

@bp.route('/history')
def get_history():
    """Получить историю сканирований"""
    try:
        if os.path.exists(HISTORY_FILE):
            with open(HISTORY_FILE, 'r', encoding='utf-8') as f:
                history = json.load(f)
        else:
            history = {'scans': []}
        
        return jsonify({
            'success': True,
            'count': len(history['scans']),
            'scans': history['scans'][-10:]  # Последние 10 записей
        })
    except Exception as e:
        return jsonify({
            'error': True,
            'message': f'Ошибка загрузки истории: {str(e)}'
        }), 500

@bp.route('/stats')
def get_stats():
    """Статистика сканирований"""
    try:
        if os.path.exists(HISTORY_FILE):
            with open(HISTORY_FILE, 'r', encoding='utf-8') as f:
                history = json.load(f)
            scans = history.get('scans', [])
        else:
            scans = []
        
        stats = {
            'total': len(scans),
            'today': len([s for s in scans if s.get('timestamp', '').startswith(
                datetime.now().strftime('%Y-%m-%d'))]),
            'clean': len([s for s in scans if s.get('verdict', {}).get('level') == 'clean']),
            'suspicious': len([s for s in scans if s.get('verdict', {}).get('level') == 'suspicious']),
            'dangerous': len([s for s in scans if s.get('verdict', {}).get('level') == 'dangerous'])
        }
        
        return jsonify({
            'success': True,
            'stats': stats,
            'last_updated': datetime.now().isoformat()
        })
    except Exception as e:
        return jsonify({
            'error': True,
            'message': str(e)
        }), 500