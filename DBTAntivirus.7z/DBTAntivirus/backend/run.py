#!/usr/bin/env python3
"""
DBT Antivirus - Main Server
Запуск: python run.py
"""
import os
import sys
from pathlib import Path

# Добавляем папку backend в путь Python
sys.path.append(str(Path(__file__).parent))

from app import create_app

app = create_app()

if __name__ == '__main__':
    print("\n" + "═" * 60)
    print("🔥 DBT ANTIVIRUS BACKEND v1.0")
    print("═" * 60)
    print("📁 Структура проекта загружена")
    print("🌐 API сервер запущен: http://localhost:5000")
    print("📊 API эндпоинты:")
    print("   POST /api/scan     - Сканирование файла")
    print("   GET  /api/history  - История сканирований")
    print("   GET  /api/stats    - Статистика")
    print("═" * 60)
    print("⚡ Используется Python", sys.version.split()[0])
    print("💡 Для остановки: Ctrl+C")
    print("═" * 60 + "\n")
    
    app.run(
        host='0.0.0.0',
        port=5000,
        debug=True,
        threaded=True
    )